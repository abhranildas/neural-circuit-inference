basedir = pwd;
addpath([basedir '/functions/']);
addpath([basedir '/functions_encoding_decoding/']);


