function [deg] = rad2deg(rad)
deg = 180*rad/pi;