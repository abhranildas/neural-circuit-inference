function [rad] = deg2rad(deg)
rad = deg*pi/180;